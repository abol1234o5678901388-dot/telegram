import os, asyncio, random, logging
from pyrogram import Client, filters

API_ID = 27210755
API_HASH = "fd8cd5a9f6014f82c5036f0af396da98"
SESSION = "BAGfNAMAYSrhKHynuqYm5ttkF9Y5u3FEdF7zoI7Jr5v92m0rNPjTh0SCCCDEB7f1ca7F3lbH0GICnm-thtw1QwcpVWh7TCFQN8eIkSG_lWU3i_3RxKcmPIGQF0xT0IQa_mGbyn2QrhwonZf-25gy9G-rnEwSm7lYBDvhbhSITAs-asxmfZTNyHta7uTrPF63Ss5ygANUcytbBoaYsSk-EdMhY3wApmoLyi6iunSnXD_E8cgboVNcBEadxRuttUbMi0m50-O9MbcV5H3_i71p7TVD582Om7CsDHsZMQHqizOpEESzr8xTTZMqKzVDukIhZoFjPIEz5xA4mi881HHjwduGE3tQwQAAAAH5v2rSAA"
ADMIN = 8485038802

app = Client("bot", api_id=API_ID, api_hash=API_HASH, session_string=SESSION)
enemies, tasks = set(), {}
os.makedirs("downloads", exist_ok=True)
KHESHAB = "downloads/Kheshab.txt"
if not os.path.exists(KHESHAB): open(KHESHAB, "w", encoding="utf-8").write("آرس شاه برزخ اومده.\n")

def rnd_text():
    try:
        lines = [l.strip() for l in open(KHESHAB, encoding="utf-8") if l.strip()]
        return random.choice(lines)
    except: return "آرس شاه برزخ اومده."

async def bomb(c, chat, t):
    while True:
        txt = rnd_text()
        if enemies: txt += " " + " ".join(f"[§](tg://user?id={u})" for u in enemies)
        try: await c.send_message(chat, txt)
        except: pass
        await asyncio.sleep(t)

@app.on_message(filters.user(ADMIN))
async def h(c, m):
    t = (m.text or "").strip()
    if (m.caption or "").strip() == "خشاب":
        try: await m.download(KHESHAB); await m.reply("✅ خشاب ذخیره شد"); return
        except: await m.reply("❌ خطا در ذخیره"); return
    if t=="set" and m.reply_to_message: enemies.add(m.reply_to_message.from_user.id); await m.reply("اضافه شد")
    elif t.startswith("in"):
        d=int(t.split()[1]) if len(t.split())>1 and t.split()[1].isdigit() else 3
        n=f"b{m.chat.id}"
        if n in tasks and not tasks[n].done(): await m.reply("در حال اجراست")
        else: tasks[n]=asyncio.create_task(bomb(c,m.chat.id,d)); await m.reply("شروع شد")
    elif t=="sinf":
        n=f"b{m.chat.id}"
        if n in tasks and not tasks[n].done(): tasks[n].cancel(); await m.reply("متوقف شد")
    elif t=="del" and m.reply_to_message:
        u=m.reply_to_message.from_user.id; enemies.discard(u); await m.reply("حذف شد")
    elif t=="all": enemies.clear(); [v.cancel() for v in tasks.values()]; tasks.clear(); await m.reply("همه پاک شدن")

print("🚀 Bot started..."); app.run()
EOFcat << 'EOF' > bot.py
import os, asyncio, random, logging
from pyrogram import Client, filters

API_ID = 
API_HASH = ""
SESSION = ""
ADMIN = 

app = Client("bot", api_id=API_ID, api_hash=API_HASH, session_string=SESSION)
enemies, tasks = set(), {}
os.makedirs("downloads", exist_ok=True)
KHESHAB = "downloads/Kheshab.txt"
if not os.path.exists(KHESHAB): open(KHESHAB, "w", encoding="utf-8").write("آرس شاه برزخ اومده.\n")

def rnd_text():
    try:
        lines = [l.strip() for l in open(KHESHAB, encoding="utf-8") if l.strip()]
        return random.choice(lines)
    except: return "آرس شاه برزخ اومده."

async def bomb(c, chat, t):
    while True:
        txt = rnd_text()
        if enemies: txt += " " + " ".join(f"[§](tg://user?id={u})" for u in enemies)
        try: await c.send_message(chat, txt)
        except: pass
        await asyncio.sleep(t)

@app.on_message(filters.user(ADMIN))
async def h(c, m):
    t = (m.text or "").strip()
    if (m.caption or "").strip() == "خشاب":
        try: await m.download(KHESHAB); await m.reply("✅ خشاب ذخیره شد"); return
        except: await m.reply("❌ خطا در ذخیره"); return
    if t=="set" and m.reply_to_message: enemies.add(m.reply_to_message.from_user.id); await m.reply("اضافه شد")
    elif t.startswith("in"):
        d=int(t.split()[1]) if len(t.split())>1 and t.split()[1].isdigit() else 3
        n=f"b{m.chat.id}"
        if n in tasks and not tasks[n].done(): await m.reply("در حال اجراست")
        else: tasks[n]=asyncio.create_task(bomb(c,m.chat.id,d)); await m.reply("شروع شد")
    elif t=="sinf":
        n=f"b{m.chat.id}"
        if n in tasks and not tasks[n].done(): tasks[n].cancel(); await m.reply("متوقف شد")
    elif t=="del" and m.reply_to_message:
        u=m.reply_to_message.from_user.id; enemies.discard(u); await m.reply("حذف شد")
    elif t=="all": enemies.clear(); [v.cancel() for v in tasks.values()]; tasks.clear(); await m.reply("همه پاک شدن")

print("🚀 Bot started..."); app.run()