#!/bin/bash
set -e

echo "Updating system..."
apt update -y
apt install -y python3 python3-pip

echo "Installing requirements..."
pip3 install -r requirements.txt

echo "Starting bot..."
python3 bot.py
