#!/usr/bin/env python3
# main.py - Godbotspam complete
# Requires: pyrogram
# Put accounts.json (list of accounts with session_name, api_id, api_hash) next to this file.

import os
import json
import random
import asyncio
from typing import Tuple, Optional, List, Dict
from pyrogram import Client, filters
from pyrogram.types import Message

# ------------------ تنظیم‌ها ------------------
ADMIN_IDS = [8485038802, 7915034757]  # <-- جای این آیدی‌ها، آیدی‌های خودت بذار
ACCOUNTS_FILE = "accounts.json"
DOWNLOADS = "downloads"
KHESHAB = os.path.join(DOWNLOADS, "Kheshab.txt")
ENEMY = os.path.join(DOWNLOADS, "Enemy.txt")  # lines like "user:12345" or "chat:-100..."
TARGET = os.path.join(DOWNLOADS, "TargetChat.txt")

os.makedirs(DOWNLOADS, exist_ok=True)
if not os.path.exists(KHESHAB):
    with open(KHESHAB, "w", encoding="utf-8") as f:
        f.write("🖕\n")
if not os.path.exists(ENEMY):
    with open(ENEMY, "w", encoding="utf-8") as f:
        f.write("")
if not os.path.exists(TARGET):
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write("none\n")

# ------------------ حالت در حافظه ------------------
auto_mode = False
auto_task: Optional[asyncio.Task] = None
clients_by_name: Dict[str, Client] = {}
bomb_tasks: Dict[str, asyncio.Task] = {}
SMART_TASKS: Dict[str, asyncio.Task] = {}

# ------------------ توابع کمکی دشمن ------------------
def get_enemies() -> List[Tuple[str, int]]:
    res = []
    try:
        if not os.path.exists(ENEMY):
            return res
        with open(ENEMY, "r", encoding="utf-8") as f:
            for ln in f.read().splitlines():
                ln = ln.strip()
                if not ln:
                    continue
                if ":" in ln:
                    t, v = ln.split(":", 1)
                    if v.lstrip("-").isdigit():
                        res.append((t, int(v)))
                else:
                    if ln.lstrip("-").isdigit():
                        res.append(("chat", int(ln)))
    except Exception as e:
        print(f"[ERROR] get_enemies: {e}")
    return res

def write_enemies(enemies: List[Tuple[str, int]]):
    try:
        with open(ENEMY, "w", encoding="utf-8") as f:
            for t, i in enemies:
                f.write(f"{t}:{i}\n")
    except Exception as e:
        print(f"[ERROR] write_enemies: {e}")

def add_enemy_id(id_val: int, typ: str = "user") -> bool:
    enemies = get_enemies()
    if any(i == id_val for (_, i) in enemies):
        return False
    enemies.append((typ, id_val))
    write_enemies(enemies)
    return True

def del_enemy_id(id_val: int) -> bool:
    enemies = get_enemies()
    new = [(t, i) for (t, i) in enemies if i != id_val]
    if len(new) == len(enemies):
        return False
    write_enemies(new)
    return True

def clear_enemies():
    write_enemies([])

def read_primary_enemy() -> Tuple[Optional[str], Optional[int]]:
    ens = get_enemies()
    return ens[0] if ens else (None, None)

# ------------------ تارگت ------------------
def read_target() -> Tuple[Optional[str], Optional[int]]:
    try:
        if not os.path.exists(TARGET):
            return None, None
        with open(TARGET, "r", encoding="utf-8") as f:
            data = f.read().strip()
            if not data or data == "none":
                return None, None
            if ":" in data:
                sess, cid = data.split(":", 1)
                if cid.lstrip("-").isdigit():
                    return sess, int(cid)
    except Exception as e:
        print(f"[ERROR] read_target: {e}")
    return None, None

def write_target(session_name: str, chat_id: int):
    try:
        with open(TARGET, "w", encoding="utf-8") as f:
            f.write(f"{session_name}:{chat_id}")
    except Exception as e:
        print(f"[ERROR] write_target: {e}")

# ------------------ خشاب ------------------
def random_fosh() -> str:
    try:
        with open(KHESHAB, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        return random.choice(lines) if lines else "🖕"
    except Exception as e:
        print(f"[ERROR] random_fosh: {e}")
        return "🖕"

def add_fosh(text: str):
    try:
        with open(KHESHAB, "a", encoding="utf-8") as f:
            f.write(text.strip() + "\n")
    except Exception as e:
        print(f"[ERROR] add_fosh: {e}")

# ------------------ ارسال ------------------
async def send_via_client(client: Client, chat_id: int, text: str) -> bool:
    try:
        await client.send_message(chat_id, text)
        return True
    except Exception as e:
        print(f"[ERROR] send_via_client: {e}")
        return False

async def send_to_target_using_session(session_name: str, chat_id: int, text: str) -> bool:
    client = clients_by_name.get(session_name)
    if not client:
        print(f"[ERROR] client {session_name} not found")
        return False
    try:
        await client.send_message(chat_id, text)
        return True
    except Exception as e:
        print(f"[ERROR] send_to_target_using_session: {e}")
        return False

# ------------------ بمب نامحدود معمولی ------------------
async def bomb_infinite_task(session_name: str, target_chat: int, user_info: Optional[Tuple[str, str]]):
    print(f"[BOMB] start infinite bomb on session={session_name} chat={target_chat}")
    try:
        while True:
            text_to_send = random_fosh()

            if user_info:
                username, display_name = user_info
                mention = f"[✧](tg://user?id={display_name})"
                text_to_send = f"{text_to_send}\n\n{mention}"

            ok = await send_to_target_using_session(session_name, target_chat, text_to_send)

            if not ok:
                print("[BOMB] failed to send")

            await asyncio.sleep(1)

    except asyncio.CancelledError:
        print(f"[BOMB] cancelled for {session_name}")
        raise
    except Exception as e:
        print(f"[BOMB] error: {e}")


def cancel_bomb_for_session(session_name: str) -> bool:
    task = bomb_tasks.get(session_name)
    if task and not task.done():
        task.cancel()
        return True
    return False

# ------------------ اتو-فحش ------------------
async def auto_fosh_loop(session_name: str):
    print(f"[AUTO] started for {session_name}")
    try:
        while True:
            sess, chat_id = read_target()
            if not sess or not chat_id or not auto_mode:
                await asyncio.sleep(5)
                continue
            type_, enemy = read_primary_enemy()
            text_to_send = random_fosh()
            if type_ == "user" and enemy:
                client_for_mention = clients_by_name.get(session_name)
                if client_for_mention:
                    username, _ = await resolve_user_info(client_for_mention, enemy)
                    if username:
                        text_to_send = f"{text_to_send}\n\n@{username}"
                    else:
                        text_to_send = f"{text_to_send}\n\ntg://user?id={enemy}"
            await send_to_target_using_session(session_name, chat_id, text_to_send)
            await asyncio.sleep(30)
    except asyncio.CancelledError:
        print("[AUTO] cancelled")
    except Exception as e:
        print(f"[AUTO] error: {e}")

# ------------------ resolve user info ------------------
async def resolve_user_info(client: Client, user_id: int) -> Tuple[Optional[str], Optional[str]]:
    try:
        u = await client.get_chat(user_id)
        username = getattr(u, "username", None)
        name = getattr(u, "first_name", None) or getattr(u, "title", None) or f"user{user_id}"
        return username, name
    except Exception:
        return None, f"user{user_id}"

# ------------------ SmartBomb (module-level helpers) ------------------
SMART_TASKS = {}  # session_name -> asyncio.Task

def make_smart_message(base_text: str, username: Optional[str]=None) -> str:
    emojis = ["🔥","💥","😈","🤬","⚡","🖕","💣","🤡"]
    tails = ["", "!", "!!", "؟", " ...", "?!"]
    templates = [
        "{base} {emoji}",
        "{emoji} {base} {emoji}",
        "{base}\n\n{mention} {emoji}",
        "{base} — {emoji}",
        "{emoji} {base} {tail}"
    ]
    tpl = random.choice(templates)
    emoji = random.choice(emojis)
    tail = random.choice(tails)
    mention = f"@{username}" if username else ""
    return tpl.format(base=base_text, emoji=emoji, tail=tail, mention=mention)

async def smartbomb_task(session_name: str, target_chat: int, user_info: Optional[Tuple[str,str]], count: Optional[int]=None):
    print(f"[𝚎𝚖𝚘𝚐𝚎 𝚜𝚙𝚊𝚖] start session={session_name} target={target_chat} count={count}")
    i = 0
    try:
        while True:
            if count is not None and i >= count:
                break
            base = random_fosh()
            username = user_info[0] if user_info else None
            msg = make_smart_message(base, username)
            jitter = random.uniform(0.2, 0.9)
            await send_to_target_using_session(session_name, target_chat, msg)
            i += 1
            await asyncio.sleep(jitter)
        print(f"[𝚎𝚖𝚘𝚐𝚎 𝚜𝚙𝚊𝚖] finished session={session_name} sent={i}")
    except asyncio.CancelledError:
        print(f"[𝚎𝚖𝚘𝚐𝚎 𝚜𝚙𝚊𝚖] cancelled session={session_name}")
        raise
    except Exception as e:
        print(f"[𝚎𝚖𝚘𝚐𝚎 𝚜𝚙𝚊𝚖] error: {e}")

def cancel_smartbomb_for_session(session_name: str) -> bool:
    t = SMART_TASKS.get(session_name)
    if t and not t.done():
        t.cancel()
        return True
    return False

# ------------------ register handlers for each client ------------------
def register_handlers_for_client(client: Client):
    # id handler (reply) - supports "/id" and "id"
    @client.on_message(filters.reply & filters.command("id", prefixes=["/", ""]))
    async def reply_get_id(c: Client, m: Message):
        if not m.reply_to_message:
            return await m.reply("❌ برای گرفتن آیدی روی پیام ریپلای کن و `id` یا `/id` بنویس.")
        replied = m.reply_to_message
        if replied.from_user:
            uid = replied.from_user.id
            username = getattr(replied.from_user, "username", None)
            fname = replied.from_user.first_name or ""
            lname = replied.from_user.last_name or ""
            fullname = (fname + " " + lname).strip()
            text = f"𝚙𝚛𝚘𝚏𝚒𝚕𝚎:\n• id: `{uid}`\n• name: {fullname}"
            if username:
                text += f"\n• username: @{username}"
            text += f'\n• Mention: [Click](tg://user?id={uid})'
            await m.reply(text, disable_web_page_preview=True)
            return
        if replied.sender_chat:
            cid = replied.sender_chat.id
            title = getattr(replied.sender_chat, "title", "") or ""
            await m.reply(f"🔎 شناسه فرستنده:\n• id: `{cid}`\n• title: {title}", disable_web_page_preview=True)
            return
        await m.reply("❌ نتونستم اطلاعات رو بخونم.")

    # admin commands handler
    @client.on_message(filters.all)
    async def admin_commands(c: Client, m: Message):
        global auto_mode, auto_task
        text = (m.text or "").strip()
        caption = m.caption or ""
        from_id = m.from_user.id if m.from_user else None

        # debug log:
        print(f"[LOG] from={from_id} chat={m.chat.id if m.chat else None} text='{text}' caption='{caption}'")
        
        # خشاب آپلود (کپشن "خشاب")
        if caption == "خشاب":
            try:
                await m.download(file_name=KHESHAB)
                await m.reply("𝙺𝚑𝚎𝚜𝚑𝚊𝚋 𝚒𝚜 𝚜𝚊𝚟𝚎𝚍")
            except Exception as e:
                await m.reply(f"𝙴𝚛𝚛𝚘𝚛 𝚗𝚘𝚝 𝚜𝚊𝚟𝚎𝚍  𝚔𝚑𝚎𝚜𝚑𝚊𝚋 :{e}")
            return

        # show kheshab
        if text == "show kheshab":
            try:
                with open(KHESHAB, "r", encoding="utf-8") as f:
                    await m.reply("📜 Kheshab:\n" + f.read())
            except Exception as e:
                await m.reply(f"𝙴𝚛𝚛𝚘𝚛 : {e}")
            return

        # افزودن فحش
        if text.startswith("addtext"):
            new_f = text.replace("addtext", "").strip()
            if new_f:
                add_fosh(new_f)
                await m.reply(f" 𝙽𝚎𝚠 𝚏𝚘𝚜𝚑 𝚜𝚎𝚗𝚍𝚎𝚍{new_f}")
            else:
                await m.reply("𝚏𝚘𝚜𝚑 𝚒𝚜 𝚗𝚘𝚝")
            return

        # del kheshab
        if text == "del kheshab":
            try:
                with open(KHESHAB, "w", encoding="utf-8") as f:
                    f.write("🖕\n")
                await m.reply("✅ خشاب ریست شد.")
            except Exception as e:
                await m.reply(f"❌ خطا: {e}")
            return

        # setenemy
        if text == "setenemy":
            if m.reply_to_message and m.reply_to_message.from_user:
                enemy_id = m.reply_to_message.from_user.id
                write_enemies([("user", enemy_id)])
                await m.reply(f" 𝙴𝚗𝚎𝚖𝚢 𝚊𝚍𝚍𝚎𝚍 user:{enemy_id}")
            else:
                enemy_chat = m.chat.id
                write_enemies([("chat", enemy_chat)])
                await m.reply(f" 𝙴𝚗𝚎𝚖𝚢 𝚌𝚑𝚊𝚝 𝚜𝚊𝚟𝚎𝚍 chat:{enemy_chat}")
            return

        # addenemy
        if text.startswith("addenemy "):
            arg = text.replace("addenemy ", "").strip()
            if arg.lstrip("-").isdigit():
                nid = int(arg)
                ok = add_enemy_id(nid, "user")
                if ok:
                    await m.reply(f"✅ دشمن اضافه شد: user:{nid}")
                else:
                    await m.reply("⚠️ این دشمن قبلاً وجود دارد.")
            else:
                await m.reply("❌ آیدی معتبر وارد کنید.")
            return

        # delenemy
        if text.startswith("delenemy"):
            arg = text.replace("delenemy ", "").strip()
            if arg.lstrip("-").isdigit():
                nid = int(arg)
                ok = del_enemy_id(nid)
                if ok:
                    await m.reply(f" 𝙴𝚗𝚎𝚖𝚢 𝙳𝚎𝚕𝚎𝚝𝚎𝚍 {nid}")
                else:
                    await m.reply("𝚃𝚑𝚒𝚜 𝚞𝚜𝚎𝚛 𝚒𝚍 𝚗𝚘𝚝 𝚏𝚘𝚞𝚗𝚍")
            else:
                await m.reply("𝚒𝚍 𝚛𝚎𝚊𝚕 𝚙𝚕𝚎𝚊𝚜𝚎")
            return

        # clearenemy -> clear all
        if text == "clearenemy":
            try:
                clear_enemies()
                await m.reply("𝙰𝚕𝚕 𝙴𝚗𝚎𝚖𝚢𝚜 𝚍𝚎𝚕𝚎𝚝𝚎𝚍")
            except Exception as e:
                await m.reply(f"𝙴𝚛𝚛𝚘𝚛 :{e}")
            return

        # listenemy
        if text == "listenemy" or text == "who enemy":
            ens = get_enemies()
            if not ens:
                await m.reply("𝙴𝚗𝚎𝚖𝚢𝚜 𝚗𝚘𝚝 𝚏𝚘𝚞𝚗𝚍")
            else:
                lines = [f"{t}:{i}" for (t, i) in ens]
                await m.reply("𝙻𝚒𝚜𝚝 𝙴𝚗𝚎𝚖𝚢𝚜 𝙴𝙽𝙴𝙼𝚈𝚂 :\n" + "\n".join(lines))
            return

        # bombnormal
        if text.startswith("spamnum on"):
            parts = text.split()
            count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 5
            target_chat = m.chat.id
            write_target(c.name, target_chat)
            type_, enemy = read_primary_enemy()
            user_info = None
            if type_ == "user" and enemy:
                username, _ = await resolve_user_info(c, enemy)
                user_info = (username, str(enemy))
            await m.reply(f" 𝚂𝚙𝚊𝚖 𝙽𝚘𝚛𝚖𝚊𝚕 𝚜𝚝𝚊𝚛𝚝𝚎𝚍({count}) 𝚒𝚗 𝚝𝚑𝚒𝚜 𝚌𝚑𝚊𝚝")
            for i in range(count):
                try:
                    msg = random_fosh()
                    if user_info:
                        username, _idstr = user_info
                        if username:
                            msg = f"{msg}\n\n@{username}"
                        else:
                            msg = f"{msg}\n\ntg://user?id={_idstr}"
                    await send_via_client(c, target_chat, msg)
                    await asyncio.sleep(0.5)
                except Exception as e:
                    await m.reply(f"𝙴𝚛𝚛𝚘𝚛 {e}")
                    break
            else:
                await m.reply("𝚜𝚙𝚊𝚖 𝚗𝚘𝚛𝚖𝚊𝚕 𝚒𝚜 𝚘𝚞𝚝")
            return

        # attack (infinite bomb)
        if text == "spam on":
            target_chat = m.chat.id
            write_target(c.name, target_chat)
            type_, enemy = read_primary_enemy()
            user_info = None
            if type_ == "user" and enemy:
                username, _ = await resolve_user_info(c, enemy)
                user_info = (username, str(enemy))
            if bomb_tasks.get(c.name) and not bomb_tasks[c.name].done():
                await m.reply("𝚃𝚑𝚒𝚜 𝚋𝚘𝚖𝚋 𝚗𝚘𝚠 𝚘𝚗")
                return
            task = asyncio.create_task(bomb_infinite_task(c.name, target_chat, user_info))
            bomb_tasks[c.name] = task
            await m.reply("𝚜𝚙𝚊𝚖 𝚑𝚊𝚜 𝚜𝚝𝚜𝚛𝚝𝚎𝚍")
            return

        # stopbomb
        if text == "spam off":
            ok = cancel_bomb_for_session(c.name)
            if ok:
                await m.reply("𝚂𝚙𝚊𝚖 𝚒𝚜 𝚘𝚏𝚏")
            else:
                await m.reply("𝚜𝚙𝚊𝚖 𝚗𝚘𝚝 𝚊𝚌𝚝𝚒𝚟𝚎𝚍")
            return

        # SmartBomb: limited
        if text.startswith("emogenum on"):
            parts = text.split()
            cnt = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 5
            target_chat = m.chat.id
            write_target(c.name, target_chat)
            type_, enemy = read_primary_enemy()
            user_info = None
            if type_ == "user" and enemy:
                username, _ = await resolve_user_info(c, enemy)
                user_info = (username, str(enemy))
            await m.reply(f"𝚜𝚖𝚊𝚛𝚝 𝚜𝚙𝚊𝚖 𝚛𝚊𝚗𝚍𝚘𝚖 𝚒𝚜 𝚜𝚝𝚊𝚛𝚝𝚎𝚍 SmartBomb ({cnt}) 𝙸𝚗 𝚝𝚑𝚒𝚜 𝚌𝚑𝚊𝚝")
            task = asyncio.create_task(smartbomb_task(c.name, target_chat, user_info, count=cnt))
            SMART_TASKS[c.name] = task
            return

        # SmartBomb: infinite
        if text == "emoge on":
            target_chat = m.chat.id
            write_target(c.name, target_chat)
            type_, enemy = read_primary_enemy()
            user_info = None
            if type_ == "user" and enemy:
                username, _ = await resolve_user_info(c, enemy)
                user_info = (username, str(enemy))
            if SMART_TASKS.get(c.name) and not SMART_TASKS[c.name].done():
                await m.reply(" 𝚂𝚙𝚊𝚖 𝚒𝚜 𝚊𝚕𝚎𝚊𝚛𝚢 𝚘𝚗")
                return
            task = asyncio.create_task(smartbomb_task(c.name, target_chat, user_info, count=None))
            SMART_TASKS[c.name] = task
            await m.reply("𝚜𝚙𝚊𝚖 𝚜𝚖𝚊𝚛𝚝 𝚒𝚜 𝚜𝚝𝚊𝚛𝚝𝚎𝚍")
            return

        # stopsmartbomb
        if text == "emoge off":
            ok = cancel_smartbomb_for_session(c.name)
            if ok:
                await m.reply("𝚜𝚙𝚊𝚖 𝚜𝚖𝚊𝚛𝚝 𝚑𝚊𝚜 𝚜𝚝𝚘𝚙𝚎𝚍")
            else:
                await m.reply("𝚜𝚙𝚊𝚖 𝚜𝚖𝚊𝚛𝚝 𝚒𝚜 𝚗𝚘𝚝 𝚘𝚗")
            return

        # toggle_auto
        if text == "toggle_auto":
            target_chat = m.chat.id
            write_target(c.name, target_chat)
            auto_mode = not auto_mode
            if auto_mode:
                if auto_task and not auto_task.done():
                    auto_task.cancel()
                globals()['auto_task'] = asyncio.create_task(auto_fosh_loop(session_name=c.name))
            else:
                if auto_task and not auto_task.done():
                    auto_task.cancel()
                    globals()['auto_task'] = None
            await m.reply(f"♻️ اتو-فحش {'روشن' if auto_mode else 'خاموش'} شد.")
            return

        # showadmins
        if text == "showadmins":
            await m.reply("👑 ادمین‌ها:\n" + "\n".join(str(a) for a in ADMIN_IDS))
            return

        # status
        if text == "status":
            ens = get_enemies()
            primary = read_primary_enemy()
            active_smart = [k for k,v in SMART_TASKS.items() if not v.done()]
            active_bombs = [k for k,v in bomb_tasks.items() if not v.done()]
            lines = [
                f"Auto: {'ON' if auto_mode else 'OFF'}",
                f"SmartBombs active: {', '.join(active_smart) if active_smart else 'none'}",
                f"Bombs active: {', '.join(active_bombs) if active_bombs else 'none'}",
                f"Enemies count: {len(ens)}",
                f"Primary: {primary[0]}:{primary[1] if primary[1] else 'none'}"
            ]
            await m.reply("📊 Status:\n" + "\n".join(lines))
            return

        # foshcount
        if text == "foshcount":
            try:
                with open(KHESHAB, "r", encoding="utf-8") as f:
                    cnt = len([l for l in f.read().splitlines() if l.strip()])
                await m.reply(f"𝙻𝚒𝚜𝚝 𝚏𝚘𝚜𝚑 𝚏𝚘𝚜𝚑{cnt}")
            except Exception as e:
                await m.reply(f"❌ خطا: {e}")
            return

        # Ping & help
        if text == "ping":
            await m.reply("𝑂𝑁𝐿𝐼𝑁𝐸\n ")
            return

        if text == "help":
            await m.reply(
                ''' 𝙷𝙴𝙻𝙿 𝙱𝙾𝚃 𝙰𝚁𝙴𝚂

▫️ 𝙰𝙳𝙳 𝙺𝙰𝚁𝙳𝙰𝙽 𝙺𝙷𝙴𝚂𝙷𝙰𝙱.𝚝𝚡𝚝 → فایل txt بفرست + کپشن "خشاب"
▫️ 𝙰𝙳𝙳 𝙺𝙰𝚁𝙳𝙰𝙱 𝚃𝙴𝚇𝚃 → `addtext` <متن>
▫️ 𝙿𝙰𝙺 𝙺𝙰𝚁𝙳𝙰𝙽 𝙺𝙷𝙴𝚂𝙷𝙰𝙱.𝚝𝚡𝚝 → `del kheshab`
▫️ 𝚂𝙴𝚃 𝙺𝙰𝚁𝙳𝙰𝙱 𝙴𝙽𝙴𝙼𝚈 → `setenemy` [Reply only]
▫️ 𝙰𝙳𝙳 𝙺𝙰𝚁𝙳𝙰𝙽 𝙴𝙽𝙴𝙼𝚈 → `addenemy` <id>
▫️ 𝙿𝙰𝙺 𝙺𝙰𝚁𝙳𝙰𝙽 𝙴𝙽𝙴𝙼𝚈 → `delenemy` <id>
▫️ 𝙿𝙰𝙺 𝙺𝙰𝚁𝙳𝙰𝙽 𝙷𝙰𝙼𝙴 𝙴𝙽𝙴𝙼𝚈 𝙷𝙰 → `clearenemy`
▫️ 𝙻𝙸𝚂𝚃 𝙴𝙽𝙴𝙼𝚈 𝙷𝙰 → `listenemy`
▫️𝚂𝙿𝙰𝙽 𝚁𝙰𝙽𝙳𝙾𝙼 𝚈𝙰 5 𝚃𝙰 → `spamnum on` <count>
▫️𝚁𝙾𝚂𝙷𝙰𝙽 𝙺𝙰𝚁𝙳𝙰𝙽 𝚂𝙿𝙰𝙼  → `spam on`
▫️ 𝙺𝙷𝙰𝙼𝙾𝚂𝙷 𝙺𝙰𝚁𝙳𝙰𝙽 𝚂𝙿𝙰𝙼 → `spam off`
▫️ 𝚁𝙾𝚂𝙷𝙰𝙽 𝙺𝙰𝚁𝙳𝙰𝙽 𝙸𝙼𝙾𝙶𝙴 𝚁𝙰𝙽𝙳𝙾𝙼 → `emogenum on` <count>
▫️ 𝚁𝙾𝚂𝙷𝙰𝙽 𝙺𝙰𝚁𝙰𝙽 𝙸𝙼𝙾𝙶𝙴 𝚂𝙿𝙰𝙼𝙼𝙴𝚁→ `emoge on`
▫️ 𝙺𝙷𝙰𝙼𝙾𝚂𝙷 𝙺𝙰𝚁𝙳𝙰𝙽 𝙸𝙼𝙾𝙶𝙴 𝚂𝙿𝙰𝙼𝙼𝙴𝚁 → `emoge off`
▫️ 𝙰𝚄𝚃𝙾 𝙵𝙾𝚂𝙷 → `toggle_auto`
▫️ 𝙰𝙳𝙼𝙸𝚂 𝙷𝙰 → `showadmins`
▫️ 𝚅𝙰𝚉𝙴𝙰𝚃 𝚁𝙾𝙱𝙰𝚃 → `status`
▫️ 𝚃𝙴𝙳𝙰𝙳 𝙵𝙾𝚂𝙷 𝙷𝙰 → `foshcount`
▫️ 𝙶𝚎𝚛𝚎𝚏𝚝𝚊𝚗 𝚒𝚍 𝚏𝚊𝚛𝚍 → `id` [reply]



𝘊𝘳𝘦𝘢𝘵𝘦𝘥 𝘈𝘳𝘦𝘴 𝘉𝘢𝘳𝘻𝘢𝘬𝘩
''', disable_web_page_preview=True)
            return 

    # end admin_commands

    # general handler: respond when primary enemy posts
    @client.on_message(filters.all)
    async def general_handler(c: Client, m: Message):
        type_, enemy = read_primary_enemy()
        if not type_ or not enemy:
            return
        try:
            if type_ == "user":
                if m.from_user and m.from_user.id == enemy:
                    username, _ = await resolve_user_info(c, enemy)
                    if username:
                        await send_via_client(c, m.chat.id, f"{random_fosh()}\n\n@{username}")
                    else:
                        await send_via_client(c, m.chat.id, f"{random_fosh()}\n\ntg://user?id={enemy}")
            elif type_ == "chat":
                if m.chat and m.chat.id == enemy:
                    await send_via_client(c, m.chat.id, random_fosh())
        except Exception as e:
            print(f"[ERROR] general_handler: {e}")

# ------------------ بارگذاری اکانت‌ها و استارت ------------------
def load_accounts() -> List[Dict]:
    if not os.path.exists(ACCOUNTS_FILE):
        print(f"[ERROR] {ACCOUNTS_FILE} وجود ندارد.")
        return []
    try:
        with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[ERROR] load_accounts: {e}")
        return []

async def main():
    ACCOUNTS = load_accounts()
    if not ACCOUNTS:
        print("[ERROR] accounts.json خالی یا وجود ندارد — برنامه متوقف شد.")
        return

    for acc in ACCOUNTS:
        name = acc.get("session_name") or acc.get("name") or acc.get("session")
        api_id = acc.get("api_id")
        api_hash = acc.get("api_hash")
        if not (name and api_id and api_hash):
            print(f"[WARN] invalid account entry: {acc}")
            continue
        try:
            c = Client(name, api_id, api_hash)
            clients_by_name[name] = c
            register_handlers_for_client(c)
        except Exception as e:
            print(f"[ERROR] creating client {name}: {e}")

    started = []
    for name, c in clients_by_name.items():
        try:
            await c.start()
            started.append(name)
            print(f"[INFO] Started client: {name}")
        except Exception as e:
            print(f"[ERROR] failed to start {name}: {e}")

    if not started:
        print("[ERROR] هیچ کلاینتی شروع نشد. خارج می‌شوم.")
        return

    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        print("Stopping...")

    for name, c in clients_by_name.items():
        try:
            cancel_bomb_for_session(name)
            cancel_smartbomb_for_session(name)
            await c.stop()
            print(f"[INFO] Stopped client: {name}")
        except Exception as e:
            print(f"[ERROR] stopping client {name}: {e}")

if __name__ == "__main__":
    asyncio.run(main())