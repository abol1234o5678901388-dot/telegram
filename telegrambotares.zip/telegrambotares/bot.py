#!/usr/bin/env python3
# main.py - Botspamking complete
# Requires: pyrogram
# Put accounts.json (list of accounts with session_name, api_id, api_hash) next to this file.

import os
import json
import random
import asyncio
from typing import Tuple, Optional, List, Dict
from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.enums import ParseMode
# ------------------ تنظیم‌ها ------------------
ADMIN_IDS = [7915034757, 8485038802]  # <-- جای این آیدی‌ها، آیدی‌های خودت بذار
ACCOUNTS_FILE = "accounts.json"
DOWNLOADS = "downloads"
KHESHAB = os.path.join(DOWNLOADS, "Kheshab.txt")
ENEMY = os.path.join(DOWNLOADS, "Enemy.txt")  # lines like "user:12345" or "chat:-100..."
TARGET = os.path.join(DOWNLOADS, "TargetChat.txt")

os.makedirs(DOWNLOADS, exist_ok=True)
if not os.path.exists(KHESHAB):
    with open(KHESHAB, "w", encoding="utf-8") as f:
        f.write("\n")
if not os.path.exists(ENEMY):
    with open(ENEMY, "w", encoding="utf-8") as f:
        f.write("")
if not os.path.exists(TARGET):
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write("none\n")
# ------------------ حالت در حافظه ------------------
auto_mode = False
auto_task: Optional[asyncio.Task] = None
clients_by_name: Dict[str, Client] = {}
bomb_tasks: Dict[str, Dict[int, asyncio.Task]] = {}
bomb_targets: Dict[str, list[int]] = {}
SMART_TASKS: Dict[str, asyncio.Task] = {}
# ------------------ توابع کمکی دشمن ---------
def get_enemies() -> List[Tuple[str, int]]:
    res = []
    try:
        if not os.path.exists(ENEMY):
            return res
        with open(ENEMY, "r", encoding="utf-8") as f:
            for ln in f.read().splitlines():
                ln = ln.strip()
                if not ln:
                    continue
                if ":" in ln:
                    t, v = ln.split(":", 1)
                    if v.lstrip("-").isdigit():
                        res.append((t, int(v)))
                else:
                    if ln.lstrip("-").isdigit():
                        res.append(("chat", int(ln)))
    except Exception as e:
        print(f"[ERROR] get_enemies: {e}")
    return res

def write_enemies(enemies: List[Tuple[str, int]]):
    try:
        with open(ENEMY, "w", encoding="utf-8") as f:
            for t, i in enemies:
                f.write(f"{t}:{i}\n")
    except Exception as e:
        print(f"[ERROR] write_enemies: {e}")

def add_enemy_id(id_val: int, typ: str = "user") -> bool:
    enemies = get_enemies()
    if any(i == id_val for (_, i) in enemies):
        return False
    enemies.append((typ, id_val))
    write_enemies(enemies)
    return True

def del_enemy_id(id_val: int) -> bool:
    enemies = get_enemies()
    new = [(t, i) for (t, i) in enemies if i != id_val]
    if len(new) == len(enemies):
        return False
    write_enemies(new)
    return True

def clear_enemies():
    write_enemies([])

def read_primary_enemy() -> Tuple[Optional[str], Optional[int]]:
    ens = get_enemies()
    return ens[0] if ens else (None, None)

# ------------------ تارگت ------------------
def read_target() -> Tuple[Optional[str], Optional[int]]:
    try:
        if not os.path.exists(TARGET):
            return None, None
        with open(TARGET, "r", encoding="utf-8") as f:
            data = f.read().strip()
            if not data or data == "none":
                return None, None
            if ":" in data:
                sess, cid = data.split(":", 1)
                if cid.lstrip("-").isdigit():
                    return sess, int(cid)
    except Exception as e:
        print(f"[ERROR] read_target: {e}")
    return None, None

def write_target(session_name: str, chat_id: int):
    try:
        with open(TARGET, "w", encoding="utf-8") as f:
            f.write(f"{session_name}:{chat_id}")
    except Exception as e:
        print(f"[ERROR] write_target: {e}")

# ------------------ خشاب ------------------
def random_fosh() -> str:
    try:
        with open(KHESHAB, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        return random.choice(lines) if lines else ""
    except Exception as e:
        print(f"[ERROR] random_fosh: {e}")
        return ""

def add_fosh(text: str):
    try:
        with open(KHESHAB, "a", encoding="utf-8") as f:
            f.write(text.strip() + "\n")
    except Exception as e:
        print(f"[ERROR] add_fosh: {e}")

# ------------------ ارسال ------------------
async def send_via_client(client: Client, chat_id: int, text: str) -> bool:
    try:
        await client.send_message(chat_id, text)
        return True
    except Exception as e:
        print(f"[ERROR] send_via_client: {e}")
        return False

async def send_to_target_using_session(session_name: str, chat_id: int, text: str) -> bool:
    client = clients_by_name.get(session_name)
    if not client:
        print(f"[ERROR] client {session_name} not found")
        return False
    try:
        await client.send_message(chat_id, text)
        return True
    except Exception as e:
        print(f"[ERROR] send_to_target_using_session: {e}")
        return False

# ------------------ infinite bomb (reply-targeted) ------------------
async def bomb_infinite_task(client: Client, session_name: str, target_chat: int, user_info: Optional[Tuple[str, str]], delay: float = 0.0, reply_to_message_id: Optional[int] = None, reply_to_chat_id: Optional[int] = None):
    print(f"[BOMB] start infinite bomb on session={session_name} chat={target_chat} delay={delay}s reply_to_msg={reply_to_message_id} reply_to_chat={reply_to_chat_id}")
    try:
        while True:
            text_to_send = random_fosh()

            if user_info:
                username, display_name = user_info
                mention = f"[✧](tg://user?id={display_name})"
                text_to_send = f"{text_to_send}\n\n{mention}"

            # If reply target provided (msg id + chat id) -> send to that chat as reply
            if reply_to_message_id and reply_to_chat_id:
                await client.send_message(chat_id=reply_to_chat_id, text=text_to_send, reply_to_message_id=reply_to_message_id)
            else:
                # fallback: send to target_chat (where command was issued or configured)
                await client.send_message(chat_id=target_chat, text=text_to_send)

            await asyncio.sleep(delay)
    except asyncio.CancelledError:
        print(f"[BOMB] cancelled for {session_name}")
        raise
    except Exception as e:
        print(f"[BOMB] error: {e}")
# ------------------ اتو-فحش ------------------
async def auto_fosh_loop(session_name: str):
    print(f"[AUTO] started for {session_name}")
    try:
        while True:
            sess, chat_id = read_target()
            if not sess or not chat_id or not auto_mode:
                await asyncio.sleep(5)
                continue
            type_, enemy = read_primary_enemy()
            text_to_send = random_fosh()
            if type_ == "user" and enemy:
                client_for_mention = clients_by_name.get(session_name)
                if client_for_mention:
                    username, _ = await resolve_user_info(client_for_mention, enemy)
            if user_info:
                username, display_name = user_info
                mention = f"[✧](tg://user?id={display_name})"
                text_to_send = f"{text_to_send}\n\n{mention}"
            await send_to_target_using_session(session_name, chat_id, text_to_send)
            await asyncio.sleep(30)
    except asyncio.CancelledError:
        print("[AUTO] cancelled")
    except Exception as e:
        print(f"[AUTO] error: {e}")

# ------------------ resolve user info ------------------
async def resolve_user_info(client: Client, user_id: int) -> Tuple[Optional[str], Optional[str]]:
    try:
        u = await client.get_chat(user_id)
        username = getattr(u, "username", None)
        name = getattr(u, "first_name", None) or getattr(u, "title", None) or f"user{user_id}"
        return username, name
    except Exception:
        return None, f"user{user_id}"

# ------------------ SmartBomb (module-level helpers) ------------------
SMART_TASKS = {}  # session_name -> asyncio.Task

def make_smart_message(base_text: str, username: Optional[str]=None) -> str:
    emojis = ["🔥","💥","😈","🤬","⚡","🖕","💣","🤡","🎉","💫","☠️","💢","✨","💤","💩","💪"]
    tails = ["", "!", "!!", "؟", " ...", "?!"]
    templates = [
        "{base} {emoji}",
        "{emoji} {base}",
        "{base} {emoji}",
        "{base} — {emoji}",
        "{emoji} {base}"
    ]
    tpl = random.choice(templates)
    emoji = random.choice(emojis)
    tail = random.choice(tails)
    mention = f"@{username}" if username else ""
    return tpl.format(base=base_text, emoji=emoji, tail=tail, mention=mention)

async def smartbomb_task(session_name: str, target_chat: int, user_info: Optional[Tuple[str,str]], count: Optional[int]=None):
    print(f"[𝚎𝚖𝚘𝚐𝚎 𝚜𝚙𝚊𝚖] start session={session_name} target={target_chat} count={count}")
    i = 0
    try:
        while True:
            if count is not None and i >= count:
                break
            base = random_fosh()
            username = user_info[0] if user_info else None
            msg = make_smart_message(base, username)
            jitter = random.uniform(0.2, 0.9)
            await send_to_target_using_session(session_name, target_chat, msg)
            i += 1
            await asyncio.sleep(jitter)
        print(f"[𝚎𝚖𝚘𝚐𝚎 𝚜𝚙𝚊𝚖] finished session={session_name} sent={i}")
    except asyncio.CancelledError:
        print(f"[𝚎𝚖𝚘𝚐𝚎 𝚜𝚙𝚊𝚖] cancelled session={session_name}")
        raise
    except Exception as e:
        print(f"[𝚎𝚖𝚘𝚐𝚎 𝚜𝚙𝚊𝚖] error: {e}")

def cancel_smartbomb_for_session(session_name: str) -> bool:
    t = SMART_TASKS.get(session_name)
    if t and not t.done():
        t.cancel()
        return True
    return False

# ------------------ register handlers for each client ------------------
def register_handlers_for_client(client: Client):
    """
    Register three handlers on the provided pyrogram Client:
      - .id / .userinfo        -> shows user info (admins only)
      - .setname <name>        -> change account first name (admins only)
      - .setfamily <family>    -> change account last name (admins only)

    Place this function in your bot code and call `register_handlers_for_client(client)` for each Client.
    """

    # ------------------ دستور userinfo / id فقط برای ادمین‌ها ------------------
    @client.on_message(filters.command(["id", "userinfo"], prefixes=[".", "/"]) & filters.user(ADMIN_IDS))
    async def userinfo_handler(c: Client, m: Message):
        try:
            # بررسی حالت‌های مختلف: ریپلای / آیدی / یوزرنیم
            if m.reply_to_message and m.reply_to_message.from_user:
                target_id = m.reply_to_message.from_user.id
            else:
                parts = (m.text or "").split()
                if len(parts) >= 2:
                    arg = parts[1]
                    if arg.startswith("@"):
                        user = await c.get_users(arg)
                        target_id = user.id
                    elif arg.isdigit():
                        target_id = int(arg)
                    else:
                        await m.reply("𝙸𝚗𝚟𝚊𝚕𝚒𝚍 𝙸𝚗𝚙𝚞𝚝. 𝚄𝚜𝚎  @username or numeric id.", quote=True)
                        return
                else:
                    target_id = m.from_user.id  # default to sender

            # گرفتن اطلاعات کاربر
            user = await c.get_users(target_id)
            photos_count = await c.get_chat_photos_count(target_id)
            full_info = await c.get_chat(target_id)

            # دانلود عکس پروفایل در صورت وجود
            photo_path = None
            try:
                if getattr(user, "photo", None):
                    photo_path = await c.download_media(user.photo.big_file_id)
            except Exception:
                photo_path = None

            # ساخت متن اطلاعات کاربر
            info_text = (
                f"𝙿𝚛𝚘𝚏𝚒𝚕𝚎\n\n"
                f"• 𝙽𝚊𝚖𝚎 : {user.first_name or '--'}\n"
                f"• 𝙻𝚊𝚜𝚝 𝙽𝚊𝚖𝚎 : {user.last_name or '--'}\n"
                f"• 𝙸𝚍 𝚄𝚜𝚎𝚛 : `{user.id}`\n"
                f"• 𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎 : @{user.username if user.username else '--'}\n"
                f"• 𝙱𝚒𝚘 : {getattr(full_info, 'bio', '--')}\n"
                f"• 𝙿𝚛𝚘𝚏𝚒𝚕𝚎 𝙿𝚑𝚘𝚝𝚘: {photos_count}\n"
                f"• 𝙸𝚜 𝙱𝚘𝚝 : {getattr(user, 'is_bot', False)}\n"
                f"• 𝙸𝚜 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 : {getattr(user, 'is_premium', False)}\n"
                f"• 𝙸𝚜 𝙳𝚎𝚕𝚎𝚝𝚎𝚍: {getattr(user, 'is_deleted', False)}\n"
                f"• 𝙸𝚜 𝚅𝚎𝚛𝚒𝚏𝚒𝚎𝚗𝚍 : {getattr(user, 'is_verified', False)}\n"
                f"• 𝙻𝚊𝚗𝚐𝚞𝚊𝚐𝚎 𝙲𝚘𝚍𝚎 : {user.language_code or '--'}\n"
                f"• 𝙲𝚞𝚛𝚛𝚎𝚗𝚝 𝙲𝚑𝚊𝚝 𝙸𝚍 : `{m.chat.id}`"
            )

            # ارسال پیام همراه عکس (در صورت وجود)
            if photo_path:
                await c.send_photo(
                    chat_id=m.chat.id,
                    photo=photo_path,
                    caption=info_text,
                    reply_to_message_id=m.id
                )
                try:
                    os.remove(photo_path)
                except Exception:
                    pass
            else:
                await m.reply(info_text, quote=True)

        except Exception as e:
            await m.edit(f"⚠️ 𝙴𝚛𝚛𝚘𝚛: {e}", quote=True)

    # ------------------ دستور setname فقط برای ادمین‌ها ------------------
    @client.on_message(filters.command("setname", prefixes=[".", "/"]) & filters.user(ADMIN_IDS))
    async def set_name_handler(c: Client, m: Message):
        try:
            parts = (m.text or "").split(maxsplit=1)
            if len(parts) < 2 or not parts[1].strip():
                await m.reply("𝙿𝚕𝚎𝚊𝚜𝚎 𝙿𝚛𝚘𝚟𝚒𝚍𝚎 𝚃𝚑𝚎 𝚗𝚎𝚠 𝙵𝚒𝚛𝚜𝚝 𝙽𝚊𝚖𝚎 𝙰𝚏𝚝𝚎𝚛 𝚃𝚑𝚎 𝙲𝚘𝚖𝚖𝚊𝚗𝚍", quote=True)
                return

            new_name = parts[1].strip()
            # update_profile changes the account's name for this client/session
            await c.update_profile(first_name=new_name)
            await m.reply(f"𝙵𝚒𝚛𝚜𝚝 𝙽𝚊𝚖𝚎 𝙲𝚑𝚊𝚗𝚐𝚎𝚍 𝚃𝚘 :  {new_name}", quote=True)
        except Exception as e:
            await m.reply(f"𝙴𝚛𝚛𝚘𝚛 𝙲𝚑𝚊𝚗𝚐𝚒𝚗𝚐 𝙵𝚒𝚛𝚜𝚝 𝙽𝚊𝚖𝚎 : {e}", quote=True)

    # ------------------ دستور setfamily فقط برای ادمین‌ها ------------------
    @client.on_message(filters.command("setfamily", prefixes=[".", "/"]) & filters.user(ADMIN_IDS))
    async def set_family_handler(c: Client, m: Message):
        try:
            parts = (m.text or "").split(maxsplit=1)
            if len(parts) < 2 or not parts[1].strip():
                await m.reply("𝙿𝚕𝚎𝚊𝚜𝚎 𝙿𝚛𝚘𝚟𝚒𝚍𝚎 𝚃𝚑𝚎 𝙽𝚎𝚠 𝙻𝚊𝚜𝚝 𝙽𝚊𝚖𝚎 𝙰𝚏𝚝𝚎𝚛 𝚃𝚑𝚎 𝙲𝚘𝚖𝚖𝚊𝚗𝚍", quote=True)
                return

            new_family = parts[1].strip()
            await c.update_profile(last_name=new_family)
            await m.reply(f"𝙻𝚊𝚜𝚝 𝙽𝚊𝚖𝚎 𝙲𝚑𝚊𝚗𝚐𝚎𝚍 𝚃𝚘 : {new_family}", quote=True)
        except Exception as e:
            await m.reply(f"𝙴𝚛𝚛𝚘𝚛 𝙲𝚑𝚊𝚗𝚐𝚒𝚗𝚐 𝙻𝚊𝚜𝚝 𝙽𝚊𝚖𝚎 : {e}", quote=True)


    # admin commands handler
    @client.on_message(filters.all)
    async def admin_commands(c: Client, m: Message):
        global auto_mode, auto_task
        text = (m.text or "").strip()
        caption = m.caption or ""
        from_id = m.from_user.id if m.from_user else None

        # debug log:
        print(f"[LOG] from={from_id} chat={m.chat.id if m.chat else None} text='{text}' caption='{caption}'")
        
           # only admins
        if from_id is None or int(from_id) not in ADMIN_IDS:
            # if they attempted admin commands, notify
            admin_cmd_prefixes = ("addtext", "setfamily", ".setfamily", "/setfamily", ".setname",  "addenemy", "setname", "/setname", "delenemy", "clearenemy", "spamnum on", "spam on", "spam off", "spamall off", "toggle_auto", "setenemy", "emogenum on", "emoge on", "emoge off")
            admin_cmds = {"help", "ping", "id", ".id", "showadmins", "/id" "listenemy", "del kheshab", "showtxt", "foshcount", "txttext", "status", "clearenemy"}
            if text in admin_cmds or any(text.startswith(p) for p in admin_cmd_prefixes):
                await m.reply("")
            return
             
        # خشاب آپلود (کپشن "خشاب")
        if caption == "txttext":
            try:
                await m.download(file_name=KHESHAB)
                await m.edit("𝙺𝚑𝚎𝚜𝚑𝚊𝚋 𝚒𝚜 𝚜𝚊𝚟𝚎𝚍")
            except Exception as e:
                await m.edit(f"𝙴𝚛𝚛𝚘𝚛 𝚗𝚘𝚝 𝚜𝚊𝚟𝚎𝚍  𝚔𝚑𝚎𝚜𝚑𝚊𝚋 :{e}")
            return

        # show kheshab
        if text == "showtxt":
            try:
                with open(KHESHAB, "r", encoding="utf-8") as f:
                    await m.edit("📜 Kheshab:\n" + f.read())
            except Exception as e:
                await m.edit(f"𝙴𝚛𝚛𝚘𝚛 : {e}")
            return

        # افزودن فحش
        if text.startswith("addtext"):
            new_f = text.replace("addtext", "").strip()
            if new_f:
                add_fosh(new_f)
                await m.edit(f" 𝙽𝚎𝚠 𝚏𝚘𝚜𝚑 𝚜𝚎𝚗𝚍𝚎𝚍{new_f}")
            else:
                await m.edit("𝚏𝚘𝚜𝚑 𝚒𝚜 𝚗𝚘𝚝")
            return

        # del kheshab
        if text == "del kheshab":
            try:
                with open(KHESHAB, "w", encoding="utf-8") as f:
                    f.write("𝚈𝙾𝚄 𝙽𝙴𝙴𝙳 𝚃𝙴𝚇𝚃\n")
                await m.edit("𝙺𝚑𝚎𝚜𝚑𝚊𝚋 𝙷𝚊𝚜 𝚁𝚎𝚜𝚎𝚝")
            except Exception as e:
                await m.edit(f"❌ خطا: {e}")
            return

        # setenemy
        if text == "setenemy":
            if m.reply_to_message and m.reply_to_message.from_user:
                enemy_id = m.reply_to_message.from_user.id
                write_enemies([("user", enemy_id)])
                await m.edit(f" 𝙴𝚗𝚎𝚖𝚢 𝚊𝚍𝚍𝚎𝚍 𝚄𝚜𝚎𝚛 :{enemy_id}")
            else:
                enemy_chat = m.chat.id
                write_enemies([("chat", enemy_chat)])
                await m.edit(f" 𝙴𝚗𝚎𝚖𝚢 𝚌𝚑𝚊𝚝 𝚜𝚊𝚟𝚎𝚍 𝙲𝚑𝚊𝚝 :{enemy_chat}")
            return

        # addenemy
        if text.startswith("addenemy "):
            arg = text.replace("addenemy ", "").strip()
            if arg.lstrip("-").isdigit():
                nid = int(arg)
                ok = add_enemy_id(nid, "user")
                if ok:
                    await m.edit(f"𝙴𝚗𝚎𝚖𝚢 𝙷𝚊𝚜 𝙰𝚍𝚍𝚎𝚍 𝚄𝚜𝚎𝚛 :{nid}")
                else:
                    await m.edit("𝚃𝚑𝚒𝚜 𝙴𝚗𝚎𝚖𝚢 𝙰𝚕𝚎𝚊𝚛𝚢 𝙻𝚒𝚜𝚝𝚎𝚍")
            else:
                await m.edit("𝚁𝚎𝚊𝚕 𝙸𝚍 𝙿𝚕𝚎𝚊𝚜𝚎")
            return

        # delenemy
        if text.startswith("delenemy"):
            arg = text.replace("delenemy ", "").strip()
            if arg.lstrip("-").isdigit():
                nid = int(arg)
                ok = del_enemy_id(nid)
                if ok:
                    await m.edit(f" 𝙴𝚗𝚎𝚖𝚢 𝙳𝚎𝚕𝚎𝚝𝚎𝚍 𝚄𝚜𝚎𝚛 :{nid}")
                else:
                    await m.edit("𝚃𝚑𝚒𝚜 𝚞𝚜𝚎𝚛 𝚒𝚍 𝚗𝚘𝚝 𝚏𝚘𝚞𝚗𝚍")
            else:
                await m.edit("𝚒𝚍 𝚛𝚎𝚊𝚕 𝚙𝚕𝚎𝚊𝚜𝚎")
            return

        # clearenemy -> clear all
        if text == "clearenemy":
            try:
                clear_enemies()
                await m.edit("𝙰𝚕𝚕 𝙴𝚗𝚎𝚖𝚢𝚜 𝚍𝚎𝚕𝚎𝚝𝚎𝚍")
            except Exception as e:
                await m.edit(f"𝙴𝚛𝚛𝚘𝚛 :{e}")
            return

        # listenemy
        if text == "listenemy" or text == "who enemy":
            ens = get_enemies()
            if not ens:
                await m.edit("𝙴𝚗𝚎𝚖𝚢𝚜 𝚗𝚘𝚝 𝚏𝚘𝚞𝚗𝚍")
            else:
                lines = [f"{t}:{i}" for (t, i) in ens]
                await m.edit("𝙻𝚒𝚜𝚝 𝙴𝚗𝚎𝚖𝚢𝚜 𝙴𝙽𝙴𝙼𝚈𝚂 :\n" + "\n".join(lines))
            return

# ------------------ Bomb fast ------------------
        if text.startswith("spamfast on"):
            parts = text.split()
            count = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 10
            target_chat = m.chat.id
            write_target(c.name, target_chat)

            await m.edit(f"𝚂𝚙𝚊𝚖 𝚒𝚜 𝚜𝚝𝚊𝚛𝚝𝚎𝚍 ({count} messages) 𝚒𝚗 𝚝𝚑𝚒𝚜 𝚌𝚑𝚊𝚝")

            for i in range(count):
                try:
                    msg = random_fosh()
                    await send_via_client(c, target_chat, msg)
                    await asyncio.sleep(0.3)
                except Exception as e:
                    await m.edit(f"𝚂𝚙𝚊𝚖 𝚒𝚜 𝙴𝚛𝚛𝚘𝚛 : {e}")
                    break
            else:
                await m.edit("𝚂𝚙𝚊𝚖 𝚜𝚞𝚌𝚌𝚎𝚜𝚜 𝚏𝚞𝚕𝚕𝚢 𝚏𝚒𝚗𝚒𝚜𝚑𝚎𝚍")
            return
            # ------------------ Bomb 𝚜𝚕𝚘𝚠------------------
        if text.startswith("spamslow on"):
            parts = text.split()
            count = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 10
            target_chat = m.chat.id
            write_target(c.name, target_chat)

            await m.edit(f"𝚂𝚙𝚊𝚖 𝚒𝚜 𝚜𝚝𝚊𝚛𝚝𝚎𝚍 ({count} messages) 𝚒𝚗 𝚝𝚑𝚒𝚜 𝚌𝚑𝚊𝚝")

            for i in range(count):
                try:
                    msg = random_fosh()
                    await send_via_client(c, target_chat, msg)
                    await asyncio.sleep(7)
                except Exception as e:
                    await m.edit(f"𝚂𝚙𝚊𝚖 𝚒𝚜 𝙴𝚛𝚛𝚘𝚛 : {e}")
                    break
            else:
                await m.edit("𝚂𝚙𝚊𝚖 𝚜𝚞𝚌𝚌𝚎𝚜𝚜 𝚏𝚞𝚕𝚕𝚢 𝚏𝚒𝚗𝚒𝚜𝚑𝚎𝚍")
            return
# ------------------ Bomb Normal ------------------
        if text.startswith("spamnorm on"):
            parts = text.split()
            count = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 10
            target_chat = m.chat.id
            write_target(c.name, target_chat)

            await m.edit(f"𝚂𝚙𝚊𝚖 𝚒𝚜 𝚜𝚝𝚊𝚛𝚝𝚎𝚍 ({count} messages) 𝚒𝚗 𝚝𝚑𝚒𝚜 𝚌𝚑𝚊𝚝")

            for i in range(count):
                try:
                    msg = random_fosh()
                    await send_via_client(c, target_chat, msg)
                    await asyncio.sleep(3)
                except Exception as e:
                    await m.edit(f"𝚂𝚙𝚊𝚖 𝚒𝚜 𝙴𝚛𝚛𝚘𝚛 : {e}")
                    break
            else:
                await m.edit("𝚂𝚙𝚊𝚖 𝚜𝚞𝚌𝚌𝚎𝚜𝚜 𝚏𝚞𝚕𝚕𝚢 𝚏𝚒𝚗𝚒𝚜𝚑𝚎𝚍")
            return
# ------------------ اسپم نامحدود ------------------
        if text.startswith("spam on"):
            parts = text.split()
            delay = 0.0
            if len(parts) >= 3 and parts[-1].replace('.', '', 1).isdigit():
                delay = float(parts[-1])

            target_chat = m.chat.id
            reply_to_msg_id = None
            reply_to_chat_id = None

            if m.reply_to_message:
                reply_to_msg_id = m.reply_to_message.id
                reply_to_chat_id = m.reply_to_message.chat.id

            write_target(c.name, target_chat)
            type_, enemy = read_primary_enemy()
            user_info = None

            if type_ == "user" and enemy:
                username, _ = await resolve_user_info(c, enemy)
                user_info = (username, str(enemy))

            # آماده‌سازی برای اسپم چند چتی
            if c.name not in bomb_tasks:
                bomb_tasks[c.name] = {}
                bomb_targets[c.name] = []

            # بررسی اسپم فعال در چت فعلی
            if target_chat in bomb_tasks[c.name] and not bomb_tasks[c.name][target_chat].done():
                await m.edit("𝚂𝚙𝚊𝚖 𝙰𝚕𝚎𝚊𝚛𝚢 𝚁𝚞𝚗𝚗𝚒𝚗𝚐")
                return

            # ایجاد تسک جدید برای این چت
            task = asyncio.create_task(
                bomb_infinite_task(c, c.name, target_chat, user_info, delay, reply_to_msg_id, reply_to_chat_id)
            )
            bomb_tasks[c.name][target_chat] = task

            # ثبت چت در لیست اسپم‌های فعال
            if target_chat not in bomb_targets[c.name]:
                bomb_targets[c.name].append(target_chat)

            msg = "𝚂𝚙𝚊𝚖 𝚂𝚝𝚊𝚛𝚝𝚎𝚍"
            if delay > 0:
                msg += f" (delay = {delay}s)"
            if reply_to_msg_id:
                msg += " (reply mode)"
            await m.edit(msg)
            return

        # ------------------ اسپم خاموش برای چت فعلی ------------------
        if text.startswith("spam off"):
            if c.name in bomb_tasks and m.chat.id in bomb_tasks[c.name]:
                task = bomb_tasks[c.name][m.chat.id]
                if task and not task.done():
                    task.cancel()
                    del bomb_tasks[c.name][m.chat.id]
                    bomb_targets[c.name].remove(m.chat.id)
                    await m.edit("𝚂𝚙𝚊𝚖 𝙸𝚗 𝚃𝚑𝚒𝚜 𝙲𝚑𝚊𝚝 𝚂𝚞𝚌𝚌𝚎𝚜𝚜 𝙵𝚞𝚕𝚕 𝚂𝚝𝚘𝚙𝚎𝚍")
                else:
                    await m.edit("𝙽𝚘 𝙰𝚌𝚝𝚒𝚟𝚎 𝚂𝚙𝚊𝚖 𝙵𝚘𝚞𝚗𝚍 𝙸𝚗 𝚃𝚑𝚒𝚜 𝙶𝚛𝚘𝚞𝚙𝚜")
            else:
                await m.edit("𝙽𝚘 𝙰𝚌𝚝𝚒𝚟𝚎 𝚂𝚙𝚊𝚖")
            return

        # ------------------ اسپم خاموش برای همه چت‌ها ------------------
        if text.startswith("spamall off"):
            any_stopped = False
            for sname, sessions in list(bomb_tasks.items()):
                for chat_id, task in list(sessions.items()):
                    if task and not task.done():
                        task.cancel()
                        any_stopped = True
                    del bomb_tasks[sname][chat_id]
                bomb_targets[sname] = []

            if any_stopped:
                await m.edit("𝙰𝚕𝚕 𝚂𝚙𝚊𝚖𝚜 𝚂𝚝𝚘𝚙𝚎𝚍 𝙸𝚗 𝙰𝚕𝚕 𝙶𝚛𝚘𝚞𝚙𝚜")
            else:
                await m.edit("𝙽𝚘 𝙰𝚌𝚝𝚒𝚟𝚒𝚝𝚎 𝚂𝚙𝚊𝚖 𝙵𝚘𝚞𝚗𝚍")
            return

        # SmartBomb: limited
        if text.startswith("emogenum on"):
            parts = text.split()
            cnt = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 10
            target_chat = m.chat.id
            write_target(c.name, target_chat)
            type_, enemy = read_primary_enemy()
            user_info = None
            if type_ == "user" and enemy:
                username, _ = await resolve_user_info(c, enemy)
                user_info = (username, str(enemy))
            await m.edit(f"𝚜𝚖𝚊𝚛𝚝 𝚜𝚙𝚊𝚖 𝚛𝚊𝚗𝚍𝚘𝚖 𝚒𝚜 𝚜𝚝𝚊𝚛𝚝𝚎𝚍 SmartBomb ({cnt}) 𝙸𝚗 𝚝𝚑𝚒𝚜 𝚌𝚑𝚊𝚝")
            task = asyncio.create_task(smartbomb_task(c.name, target_chat, user_info, count=cnt))
            SMART_TASKS[c.name] = task
            return

        # SmartBomb: infinite
        if text == "emoge on":
            target_chat = m.chat.id
            write_target(c.name, target_chat)
            type_, enemy = read_primary_enemy()
            user_info = None
            if type_ == "user" and enemy:
                username, _ = await resolve_user_info(c, enemy)
                user_info = (username, str(enemy))
            if SMART_TASKS.get(c.name) and not SMART_TASKS[c.name].done():
                await m.edit(" 𝚂𝚙𝚊𝚖 𝚒𝚜 𝚊𝚕𝚎𝚊𝚛𝚢 𝚘𝚗")
                return
            task = asyncio.create_task(smartbomb_task(c.name, target_chat, user_info, count=None))
            SMART_TASKS[c.name] = task
            await m.edit("𝚜𝚙𝚊𝚖 𝚜𝚖𝚊𝚛𝚝 𝚒𝚜 𝚜𝚝𝚊𝚛𝚝𝚎𝚍")
            return

        # stopsmartbomb
        if text == "emoge off":
            ok = cancel_smartbomb_for_session(c.name)
            if ok:
                await m.edit("𝚜𝚙𝚊𝚖 𝚜𝚖𝚊𝚛𝚝 𝚑𝚊𝚜 𝚜𝚝𝚘𝚙𝚎𝚍")
            else:
                await m.edit("𝚜𝚙𝚊𝚖 𝚜𝚖𝚊𝚛𝚝 𝚒𝚜 𝚗𝚘𝚝 𝚘𝚗")
            return

        # toggle_auto
        if text == "toggle_auto":
            target_chat = m.chat.id
            write_target(c.name, target_chat)
            auto_mode = not auto_mode
            if auto_mode:
                if auto_task and not auto_task.done():
                    auto_task.cancel()
                globals()['auto_task'] = asyncio.create_task(auto_fosh_loop(session_name=c.name))
            else:
                if auto_task and not auto_task.done():
                    auto_task.cancel()
                    globals()['auto_task'] = None
            await m.edit(f"𝙰𝚞𝚝𝚘 𝙵𝚘𝚜𝚑 {'𝚂𝚝𝚊𝚛𝚝' if auto_mode else '𝙾𝚏𝚏'} 𝙲𝚘𝚗𝚗𝚎𝚌𝚝")
            return

        # showadmins
        if text == "showadmins":
            await m.edit("𝙰𝚍𝚖𝚒𝚗𝚜 :\n" + "\n".join(str(a) for a in ADMIN_IDS))
            return

# status
        if text == "status":
            from datetime import datetime

            # تاریخ و ساعت فعلی
            now = datetime.now()
            current_time = now.strftime("%H:%M:%S")
            current_date = now.strftime("%d/%m/%Y")
            current_day = now.strftime("%A")  # نام روز هفته

            # دشمنان و دشمن اصلی
            ens = get_enemies()
            primary = read_primary_enemy()

            # Smart tasks فعال
            active_smart = [k for k,v in SMART_TASKS.items() if not v.done()]

            # Bomb tasks فعال در هر چت
            active_bombs = {}
            for cname, chats in bomb_tasks.items():
                for chat_id, task in chats.items():
                    if not task.done():
                        active_bombs[chat_id] = task

            # خطوط نمایش وضعیت با طراحی حرفه‌ای
            lines = [
                f"𝙳𝚊𝚝𝚎 : {current_date} ({current_day})",
                f"𝚃𝚒𝚖𝚎 : {current_time}",
                f"𝙰𝚞𝚝𝚘 𝙼𝚘𝚍𝚎 : {'ON' if auto_mode else 'OFF'}",
                f"𝚂𝚖𝚊𝚛𝚝 𝚂𝚙𝚊𝚖 𝙰𝚌𝚝𝚒𝚟𝚎 : {', '.join(active_smart) if active_smart else 'None'}",
                "𝚂𝚙𝚊𝚖𝚜 𝙰𝚌𝚝𝚒𝚟𝚎 𝙸𝚗 𝙲𝚑𝚊𝚝 :"
            ]

            if active_bombs:
                for chat_id in active_bombs:
                    try:
                        chat_title = (await c.get_chat(chat_id)).title
                        display_name = chat_title if chat_title else str(chat_id)
                    except:
                        display_name = str(chat_id)
                    lines.append(f"   - {display_name} 𝙰𝚌𝚝𝚒𝚟𝚎")
                lines.append(f"   𝚃𝚘𝚝𝚊𝚕 𝙰𝚌𝚝𝚒𝚟𝚎 𝚂𝚙𝚊𝚖𝚜 : {len(active_bombs)}")
            else:
                lines.append("   None")

            lines.append(f"𝙴𝚗𝚎𝚖𝚢𝚜 𝙲𝚘𝚞𝚗𝚝 : {len(ens)}")
            lines.append(f"𝙿𝚛𝚒𝚖𝚊𝚛𝚢 𝙴𝚗𝚎𝚖𝚢𝚜 : {primary[0]}:{primary[1] if primary[1] else 'None'}")

            # خطوط جداکننده زیبا
            final_text = "𝙱𝚘𝚝 𝚂𝚝𝚊𝚝𝚞𝚜\n" + "─────────────────────────\n" + "\n".join(lines) + "\n─────────────────────────"

            # ویرایش پیام دستور با متن حرفه‌ای
            await m.edit(final_text)
            return

        # foshcount
        if text == "foshcount":
            try:
                with open(KHESHAB, "r", encoding="utf-8") as f:
                    cnt = len([l for l in f.read().splitlines() if l.strip()])
                await m.edit(f"𝙻𝚒𝚜𝚝 𝚏𝚘𝚜𝚑 𝚏𝚘𝚜𝚑{cnt}")
            except Exception as e:
                await m.edit(f"❌ خطا: {e}")
            return

        # Ping & help
        if text == "ping":
            await m.edit("𝙸𝙼 𝙾𝙽𝙻𝙸𝙽𝙴\n ")
            return

# ------------------ HELP MENU DESIGN ----------------
        if text in ["help", "/help"]:
            await m.edit(
            """ 𝙷𝙴𝙻𝙿 𝙼𝙴𝙽𝚄

  › `help1` — ℎ𝑒𝑙𝑝 𝑏𝑜𝑡 𝟏 𝑒𝑛𝑒𝑚𝑦𝑠 
  › `help2` — ℎ𝑒𝑙𝑝 𝑏𝑜𝑡 𝟐 𝑠𝑝𝑎𝑚 𝑎𝑛𝑑 𝑡𝑒𝑥𝑡
  › `help3` — ℎ𝑒𝑙𝑝 𝟑 𝑏𝑜𝑡 𝑠𝑡𝑎𝑡𝑢𝑠 𝑎𝑛𝑑 𝑠𝑒𝑡𝑡𝑖𝑛𝑔𝑠

└────────────────────────┘
         𝘾𝙧𝙚𝙖𝙩𝙚𝙙 𝘽𝙮 𝘼𝙧𝙚𝙨 𝘽𝙖𝙧𝙯𝙖𝙠𝙝""",
            disable_web_page_preview=True
        )

        if text in ["help1"]:
            await m.edit(
            """ 𝙷𝙴𝙻𝙿 𝙿𝙰𝚁𝚃 1
          


  • `addenemy` — ᵃᵈᵈ ⁿᵉʷ ᵉⁿᵉᵐʸ ᶠᵒʳ ᵐᵉⁿᵗᶦᵒⁿ ᵒⁿˡʸ ᵘˢᵉʳ ᶦᵈ
  • `delenemy` — ᵈᵉˡ ᵒⁿᵉ ᵉⁿᵉᵐʸ ᵒⁿˡʸ ᵘˢᵉʳ ᶦᵈ
  • `clearenemy`— ᵈᵉˡ ᵃˡˡ ᵉⁿᵉᵐʸˢ
  • `listenemy` — ˢᵉᵉ ˡᶦˢᵗ ᵉⁿᵉᵐʸ ᵗᵃᵍˢ ᶠᵒʳ ᵐᵉⁿᵗᶦᵒⁿ ˢᵖᵃᵐ
  • `setenemy` — ᵃᵈᵈ ᵉⁿᵉᵐʸ ᶠᵒʳ ᵐᵉⁿᵗᶦᵒⁿ ᵒⁿˡʸ ʳᵉᵖˡʸ
  ____________ 𝙲𝚕𝚒𝚌𝚔 𝙵𝚘𝚛 𝙲𝚘𝚙𝚢 `help2`
  ────────────────────────
         𝘾𝙧𝙚𝙖𝙩𝙚𝙙 𝘽𝙮 𝘼𝙧𝙚𝙨 𝘽𝙖𝙧𝙯𝙖𝙠𝙝""",
            disable_web_page_preview=True
        )

        if text in ["help2"]:
            await m.edit(
            """ 𝙷𝙴𝙻𝙿 𝙿𝙰𝚁𝚃 2

  • `addtext` — ᵃᵈᵈ ʸᵒᵘʳ ᵗᵉˣᵗ 
  • `txttext` — ᵃᵈᵈ ʸᵒᵘ ᵏʰᵉˢʰᵃᵇ.ᵗˣᵗ
  • `showtxt` — ᵃᵈᵈ ʸᵒᵘ ᵏʰᵉˢʰᵃᵇ.ᵗˣᵗ
  • `del kheshab` — ᵈᵉˡ ʸᵒᵘ ᵏʰᵉˢʰᵃᵇ.ᵗˣᵗ
  • `spamslow on`/ `spamnorm on`/ `spamfast on` — ᵗʰᶦˢ ᶦˢ ᵃ ˢᵖᵃᵐ ᶜᵒᵘⁿᵗ ᵗᵃᵏᵉ ʸᵒᵘ ᶜᵃⁿ ˢᵉᵗ ᵀᵉᵈᵃᵈ ˢᵖᵃᵐ [ᵀᵉᵈᵃᵈ ˢᵖᵃᵐ]
  • `spam on/off` — ˢᵗᵃʳᵗ ˢᵖᵃᵐ ᶦⁿ [ʳᵉᵖˡʸ ᵒʳ ⁿᵒ]
   [ˢᵉᵗ ᵗᶦᵐᵉ 𝟶 ᵗᵒ 𝟼𝟶 ˢᵉᶜᵒⁿᵈˢ]
  • `sapmall off` — ᵃˡˡ ˢᵖᵃⁿ ᵍʳᵒᵘᵖˢ ᶦˢ ᵒᶠᶠ
  • `emoge on/off` — ˢᵖᵃᵐ ᶦⁿᶠᶦⁿᶦᵗᵉ ᵉᵐᵒᵍᵉ
  • `emogenum on` — ˢᵖᵃᵐ ᵉᵐᵒʲᶦˢ ᶦⁿ 𝟹𝟶 ᵗᶦᵐᵉˢ 
  
  ____________ 𝙲𝚕𝚒𝚌𝚔 𝙵𝚘𝚛 𝙲𝚘𝚙𝚢 `help3`
  ────────────────────────
         𝘾𝙧𝙚𝙖𝙩𝙚𝙙 𝘽𝙮 𝘼𝙧𝙚𝙨 𝘽𝙖𝙧𝙯𝙖𝙠𝙝""",
            disable_web_page_preview=True
        )

        if text in ["help3"]:
            await m.edit(
            """ 𝙷𝙴𝙻𝙿 𝙿𝙰𝚁𝚃 3 

  • `toggle_auto` — ᵃᵘᵗᵒ ᵐᵒᵈᵉ 
  • `showadmins `— ˢᵉᵉ ʸᵒᵘʳ ᵃᵈᵐᶦⁿˢ ᵇᵒᵗ
  • `status` — ˢᵗᵃᵗᵘˢ ᵇᵒᵗ 
  • `foshcount` — ᵀᵉᵈᵃᵈ ᶠᵒˢʰ ˡᶦˢᵗ ᵏʰᵉˢʰᵃᵇ
  • `.id` — ᵍᵉᵗ ᵖʳᵒᶠᶦˡᵉ ᵘˢᵉʳˢ ᵒⁿˡʸ ʳᵉᵖˡʸ
  • `.setname` — ᶜʰᵃⁿᵍᵉ ʸᵒᵘʳ ᵃᶜᶜᵒᵘⁿᵗ ⁿᵃᵐᵉ
  • `.setfamily` — ᶜʰᵃⁿᵍᵉ ʸᵒᵘʳ ᵃᶜᶜᵒᵘⁿᵗ ˡᵃˢᵗⁿᵃᵐᵉ
────────────────────────
         𝘾𝙧𝙚𝙖𝙩𝙚𝙙 𝘽𝙮 𝘼𝙧𝙚𝙨 𝘽𝙖𝙧𝙯𝙖𝙠𝙝""",
            disable_web_page_preview=True
        )
    # end admin_commands

    # general handler: respond when primary enemy posts
    @client.on_message(filters.all)
    async def general_handler(c: Client, m: Message):
        type_, enemy = read_primary_enemy()
        if not type_ or not enemy:
            return
        try:
            if type_ == "user":
                if m.from_user and m.from_user.id == enemy:
                    username, _ = await resolve_user_info(c, enemy)
                    if username:
                        await send_via_client(c, m.chat.id, f"{random_fosh()}\n\n@{username}")
                    else:
                        await send_via_client(c, m.chat.id, f"{random_fosh()}\n\ntg://user?id={enemy}")
            elif type_ == "chat":
                if m.chat and m.chat.id == enemy:
                    await send_via_client(c, m.chat.id, random_fosh())
        except Exception as e:
            print(f"[ERROR] general_handler: {e}")

# ------------------ بارگذاری اکانت‌ها و استارت ------------------
def load_accounts() -> List[Dict]:
    if not os.path.exists(ACCOUNTS_FILE):
        print(f"[ERROR] {ACCOUNTS_FILE} وجود ندارد.")
        return []
    try:
        with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[ERROR] load_accounts: {e}")
        return []

async def main():
    ACCOUNTS = load_accounts()
    if not ACCOUNTS:
        print("[ERROR] accounts.json خالی یا وجود ندارد — برنامه متوقف شد.")
        return

    for acc in ACCOUNTS:
        name = acc.get("session_name") or acc.get("name") or acc.get("session")
        api_id = acc.get("api_id")
        api_hash = acc.get("api_hash")
        if not (name and api_id and api_hash):
            print(f"[WARN] invalid account entry: {acc}")
            continue
        try:
            c = Client(name, api_id, api_hash)
            clients_by_name[name] = c
            register_handlers_for_client(c)
        except Exception as e:
            print(f"[ERROR] creating client {name}: {e}")

    started = []
    for name, c in clients_by_name.items():
        try:
            await c.start()
            started.append(name)
            print(f"[INFO] Started client: {name}")
        except Exception as e:
            print(f"[ERROR] failed to start {name}: {e}")

    if not started:
        print("[ERROR] هیچ کلاینتی شروع نشد. خارج می‌شوم.")
        return

    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        print("Stopping...")

    for name, c in clients_by_name.items():
        try:
            cancel_bomb_for_session(name)
            cancel_smartbomb_for_session(name)
            await c.stop()
            print(f"[INFO] Stopped client: {name}")
        except Exception as e:
            print(f"[ERROR] stopping client {name}: {e}")

if __name__ == "__main__":
    asyncio.run(main())